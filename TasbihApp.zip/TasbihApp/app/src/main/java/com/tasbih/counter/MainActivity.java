package com.tasbih.counter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Shows the tasbih web page inside a WebView.
 *
 * The page is stored in the app (assets/index.html). On every start the app also asks the
 * web address written in assets/update_url.txt for a newer index.html. When one is found it is
 * saved on the phone and shown, so a new version only needs an upload to GitHub, not a new install.
 */
public class MainActivity extends Activity {

    // Keeping this base address the same keeps the saved counts when the page is replaced.
    private static final String BASE = "file:///android_asset/";
    private static final String MARKER = "tasbih-counter-v1";
    private static final long RECHECK_MS = 10 * 60 * 1000L;

    private WebView web;
    private File cacheFile;
    private volatile String shown;
    private volatile boolean checking = false;
    private long lastCheck = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(0xFF13806A);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        cacheFile = new File(getFilesDir(), "web-index.html");

        // A newly installed app always starts from its own bundled page.
        SharedPreferences prefs = getSharedPreferences("tasbih", MODE_PRIVATE);
        int installed = BuildConfigVersion.code(this);
        if (prefs.getInt("installed", -1) != installed) {
            //noinspection ResultOfMethodCallIgnored
            cacheFile.delete();
            prefs.edit().putInt("installed", installed).apply();
        }

        String html = readFile(cacheFile);
        if (html == null) html = readAsset("index.html");
        if (html == null) html = "<h3>index.html পাওয়া যায়নি</h3>";
        show(html);
        checkForUpdate();
    }

    private void show(String html) {
        shown = html;
        web.loadDataWithBaseURL(BASE, html, "text/html", "UTF-8", null);
    }

    private void checkForUpdate() {
        if (checking) return;
        final String address = readAsset("update_url.txt");
        if (address == null || address.trim().isEmpty()) return;
        checking = true;
        lastCheck = System.currentTimeMillis();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(address.trim() + "?t=" + System.currentTimeMillis());
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setUseCaches(false);
                    c.setRequestProperty("Cache-Control", "no-cache");
                    if (c.getResponseCode() != 200) return;
                    final String body = readAll(c.getInputStream());
                    // Only accept a complete page of this app.
                    if (body.length() < 5000 || !body.contains(MARKER)) return;
                    if (body.equals(shown)) return;
                    writeFile(cacheFile, body);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isFinishing()) show(body);
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    checking = false;
                }
            }
        }).start();
    }

    private static String readAll(InputStream in) throws java.io.IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            in.close();
        }
    }

    private String readAsset(String name) {
        try {
            return readAll(getAssets().open(name));
        } catch (Exception e) {
            return null;
        }
    }

    private static String readFile(File f) {
        try {
            if (!f.exists()) return null;
            return readAll(new java.io.FileInputStream(f));
        } catch (Exception e) {
            return null;
        }
    }

    private static void writeFile(File f, String text) {
        try {
            File tmp = new File(f.getPath() + ".tmp");
            FileOutputStream o = new FileOutputStream(tmp);
            o.write(text.getBytes(StandardCharsets.UTF_8));
            o.close();
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(f);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (System.currentTimeMillis() - lastCheck > RECHECK_MS) checkForUpdate();
    }

    @Override
    public void onBackPressed() {
        // If the settings sheet is open, close it first. Otherwise leave the app.
        web.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');"
            + "if(s&&!s.hidden){document.getElementById('closeSheet').click();return 1;}return 0;})()",
            new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    if (!"1".equals(value)) finish();
                }
            });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
