package com.tasbih.counter;

import android.content.Context;
import android.content.pm.PackageInfo;

final class BuildConfigVersion {
    private BuildConfigVersion() { }

    @SuppressWarnings("deprecation")
    static int code(Context c) {
        try {
            PackageInfo p = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return p.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }
}
